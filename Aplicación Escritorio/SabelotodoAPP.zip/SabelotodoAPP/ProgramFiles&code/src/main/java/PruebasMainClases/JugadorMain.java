package PruebasMainClases;

import Modelo.Jugador;

public class JugadorMain {
    public static void main(String[] args){
        Jugador j = new Jugador("PF", 12);
        System.out.println(j);
    }
}
