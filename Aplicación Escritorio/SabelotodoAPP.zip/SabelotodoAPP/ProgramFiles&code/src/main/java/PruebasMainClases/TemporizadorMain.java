package PruebasMainClases;

import Modelo.Temporizador;

public class TemporizadorMain {
    public static void main(String[] args){
        Temporizador t = new Temporizador(5);
        t.start();

    }
}
