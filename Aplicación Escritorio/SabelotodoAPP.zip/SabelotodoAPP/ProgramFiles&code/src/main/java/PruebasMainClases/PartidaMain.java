package PruebasMainClases;

import Modelo.Partida;

public class PartidaMain {

    public static void main(String[] args) {
        Partida p = new Partida("Carlos", "facil");
        System.out.println(p);

        p.avanzarFicha(1);
    }

}
