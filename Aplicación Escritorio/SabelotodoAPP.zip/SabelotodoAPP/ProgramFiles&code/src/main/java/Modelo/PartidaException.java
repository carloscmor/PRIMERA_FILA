package Modelo;

public class PartidaException extends Exception {

	public PartidaException() {
		super();
	}

	public PartidaException(String message) {
		super(message);
	}
}
